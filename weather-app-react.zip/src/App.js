import React from 'react';
import GetWeather from './components/get-weather';
import Weather from './components/weather';

const App = () => {

    return (
        <div className="container">
            <GetWeather />
            <Weather />
        </div>
    )
}

export default App;
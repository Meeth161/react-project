import fetch from 'cross-fetch';

export function getWeather(weather) {
    return {
        type: 'GET_WEATHER',
        payload: weather
    }
}

export function fetchWeather(city) {

    const API_KEY = /*'Put Your API Keyhere'*/'';
    const URL = 'https://api.openweathermap.org/data/2.5';

    return function (dispatch) {

        if (city !== '') {
            return fetch(`${URL}/forecast?q=${city}&appid=${API_KEY}`)
                .then(
                    response => response.json(),
                    error => console.log('An Error Occured ', error)
                )
                .then(
                    data => {
                        dispatch(getWeather(data));
                    },
                    error => console.log('An Error Occured', error)
                )
        } else {
            alert('Enter a City')
        }

    }

}
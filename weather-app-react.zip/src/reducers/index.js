import { combineReducers } from 'redux';

const intitialWeatherData = {
    city: null,
    country: null,
    weather: [],
    isAvailable: false
};


export function weatherDataReducer(weatherData = intitialWeatherData, action) {

    if (action.type === 'GET_WEATHER') {
        let data = action.payload.list.filter((n, i) => i % 8 === 0);
        data = data.map((d, i) => ({
            id: i,
            date: d.dt,
            day: new Date(d.dt*1000).getDay(),
            temp: d.main.temp,
            min_temp: d.main.temp_min,
            max_temp: d.main.temp_max,
            humidity: d.main.humidity,
            main: d.weather[0].main,
            wind: d.wind.speed,
            desc: d.weather[0].description,
            pressure: d.main.pressure,
            iconURL: `http://openweathermap.org/img/wn/${d.weather[0].icon}@2x.png`
        }));

        return Object.assign({}, weatherData, {
            city: action.payload.city.name,
            country: action.payload.city.country,
            weather: [...data],
            isAvailable: true
        })

    }

    return weatherData;

}

export default combineReducers({
    weatherData: weatherDataReducer
})
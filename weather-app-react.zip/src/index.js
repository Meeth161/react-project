import App from './App';

import React from 'react';
import ReactDOM from 'react-dom';
import thunkMiddleware from 'redux-thunk';

import { Provider } from 'react-redux';
import { createStore, applyMiddleware } from 'redux';

import reducers from './reducers';

import 'bootstrap/dist/css/bootstrap.min.css'

ReactDOM.render(
    <Provider store={createStore(reducers, applyMiddleware(thunkMiddleware))}>
        <App />
    </Provider>,
    document.querySelector('#root')
);

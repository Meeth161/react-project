import React, { Component } from 'react';
import { connect } from 'react-redux';
import { fetchWeather } from '../actions';

export class GetWeather extends Component {

    constructor(props) {
        super(props);
        this.state = {
            tempCity:''
        }
    }

    render() {
        return (
            <div className="jumbotron my-5 shadow" id="main">
                <p className="display-2 text-center">Weather App</p>
                <div className="input-group input-group-lg my-5">
                    <div className="input-group-prepend">
                        <button className="btn btn-primary" type="button" id="btn-get-weather"><i className="fa fa-map-marker"></i></button>
                    </div>
                    <span className="input-group-btn"><i className="fa fa-map-marker-alt"></i></span>
                    <input type="text" className="form-control" placeholder="Enter City" name="input_city" onChange={(e) => {this.setState({tempCity: e.target.value})}}></input>
                    <div className="input-group-append">
                        <button className="btn btn-primary" onClick={() => {this.props.fetchWeather(this.state.tempCity)}} type="button" id="btn-get-weather">Get Weather</button>
                    </div>
                </div>
            </div>
        )
    }

}

const mapStateToProps = state => ({ data: state.weatherData })

export default connect(mapStateToProps, { fetchWeather })(GetWeather);
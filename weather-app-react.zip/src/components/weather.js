import React, { Component } from 'react';
import { connect } from 'react-redux';

class Weather extends Component {

    render() {

        const weatherList = this.props.data.weather.map(data => (
            <div className="col-2" key={data.id}>
                <div className="card p-2 shadow">
                    <p className="text-center">{this.props.data.day}</p>
                    <img src={data.iconURL} alt='' className='rounded mx-auto d-block'></img>
                    {data.max_temp - 273.15}&#8451;&nbsp;{data.min_temp - 273.15}&#8451;
                </div>
            </div>
        ))

        return (
            <div className="container">
                <p className='display-4'>Weather in {this.props.data.city}, {this.props.data.country}:</p>
                <div className="row my-3">
                    {weatherList}
                </div>
            </div>
        );
    }

}

const mapStateToProps = state => ({ data: state.weatherData })

export default connect(mapStateToProps)(Weather);